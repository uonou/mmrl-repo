/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   theme.js — Theme & language management + bottom sheets
   (translations live in js/i18n.js + js/lang/*.js)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */

/* ─── Theme ───
   Glass: every theme is a full palette. Paper: surfaces stay neutral, so the color themes
   collapse into Mode (auto/dark/light/amoled) + a separate Accent (applyAccent). A color theme
   picked in Glass shows as Dark + that theme's accent in Paper; the saved theme is untouched. */
const COLOR_THEME_ACCENT = { site:'blue', emerald:'emerald', ember:'ember', rose:'rose', nord:'frost' };
const isPaper = () => document.documentElement.dataset.style === 'paper';
// the theme option shown as selected (Paper maps a color theme to Dark)
const shownTheme = t => (isPaper() && COLOR_THEME_ACCENT[t]) ? 'dark' : t;

function applyTheme(theme) {
  State.theme = theme;
  const html = document.documentElement;
  if (theme === 'auto') {
    html.setAttribute('data-theme', window.matchMedia('(prefers-color-scheme:dark)').matches ? 'amoled' : 'light');
  } else {
    html.setAttribute('data-theme', shownTheme(theme));
  }
  applyAccent();
  // Keep the status-bar tint (theme-color meta) in sync with the resolved base
  // colour, so the system bar matches instead of showing a black band.
  try {
    const base = getComputedStyle(html).getPropertyValue('--bg-base').trim();
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta && base) meta.setAttribute('content', base);
  } catch(_) {}
  // Update sheet options
  $$('.sheet-option[data-theme-option]').forEach(o => o.classList.toggle('selected', o.dataset.themeOption === shownTheme(theme)));
  // Update hint on settings row (localized)
  const hint = $('#themeRowHint');
  if (hint) hint.textContent = I18N.t('theme_' + shownTheme(theme));
  try { localStorage.setItem('copg-theme', theme); } catch(_) {}
}

/* ─── Accent (Paper only — css/paper.css reads html[data-accent]) ─── */
const ACCENTS = ['indigo','blue','emerald','ember','rose','frost'];
function savedAccent() { try { return localStorage.getItem('copg-accent'); } catch(_) { return null; } }
function applyAccent(accent) {
  if (accent) { try { localStorage.setItem('copg-accent', accent); } catch(_) {} }
  // no explicit pick yet → follow the Glass color theme, else indigo
  let a = accent || savedAccent() || COLOR_THEME_ACCENT[State.theme] || 'indigo';
  if (!ACCENTS.includes(a)) a = 'indigo';
  document.documentElement.setAttribute('data-accent', a);
  $$('.sheet-option[data-accent-option]').forEach(o => o.classList.toggle('selected', o.dataset.accentOption === a));
  const hint = $('#accentRowHint');
  if (hint) hint.textContent = I18N.t('accent_' + a);
}

/* ─── Style (Glass / Paper) — orthogonal to theme; see css/paper.css ─── */
function applyStyle(style) {
  if (style !== 'paper') style = 'glass';
  document.documentElement.setAttribute('data-style', style);
  $$('.sheet-option[data-style-option]').forEach(o => o.classList.toggle('selected', o.dataset.styleOption === style));
  const hint = $('#styleRowHint');
  if (hint) hint.textContent = I18N.t('style_' + style);
  try { localStorage.setItem('copg-style', style); } catch(_) {}
}

/* ─── Language ─── */
function applyLanguage(lang) {
  State.language = I18N.setLang(lang);
  I18N.apply();                       // translates [data-i18n], sets <html lang/dir>

  // Reflect selection + hint
  $$('.sheet-option[data-lang]').forEach(o => o.classList.toggle('selected', o.dataset.lang === State.language));
  const langHint = $('#langRowHint');
  if (langHint) langHint.textContent = I18N.meta(State.language).name || State.language;
  // Theme hint is language-dependent too
  const themeHint = $('#themeRowHint');
  if (themeHint) themeHint.textContent = I18N.t('theme_' + shownTheme(State.theme));
  applyAccent();                      // relabel the accent hint
  const styleHint = $('#styleRowHint');
  if (styleHint) styleHint.textContent = I18N.t('style_' + (document.documentElement.dataset.style || 'glass'));

  if (typeof updateHeroStatus === 'function') updateHeroStatus();
  if (window.License && License.relabel) License.relabel();
  // Re-render anything built dynamically with I18N.t() at render time —
  // I18N.apply() only touches static [data-i18n] nodes, so library cards,
  // the sort-pill labels and filter chips would otherwise keep the old language.
  if (typeof updateSortLabels === 'function') updateSortLabels();
  if (typeof renderDevices === 'function')    renderDevices();
  if (typeof renderPackages === 'function')   renderPackages();
  try { localStorage.setItem('copg-lang', State.language); } catch(_) {}
}

/* ─── Build the language sheet from registered languages ─── */
function buildLangSheet() {
  const body = $('#langSheet .sheet-body');
  if (!body) return;
  body.innerHTML = '';
  I18N.languages().forEach(l => {
    const row = document.createElement('div');
    row.className = 'sheet-option';
    row.dataset.lang = l.code;
    row.innerHTML =
      `<div class="sheet-option__icon" style="font-size:1.2rem;background:transparent;border:none;">${l.flag}</div>` +
      `<span class="sheet-option__label">${l.name}</span>` +
      `<svg class="sheet-option__check" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`;
    row.addEventListener('click', () => { applyLanguage(l.code); closeAllSheets(); });
    body.appendChild(row);
  });
}

/* ─── Bottom sheet helpers ─── */
// Clear any inline transform/transition left by a drag-to-dismiss gesture — it
// would otherwise override `.bottom-sheet.open` and keep the sheet off-screen.
function clearSheetDrag(el) { if (el) { el.style.transition = ''; el.style.transform = ''; } }

function openSheet(sheetId) {
  const overlay = $('#sheetOverlay');
  const sheet   = $(`#${sheetId}`);
  if (!overlay || !sheet) return;
  overlay.classList.add('visible');
  clearSheetDrag(sheet);
  requestAnimationFrame(() => sheet.classList.add('open'));
}

function closeSheet(sheetId) {
  const overlay = $('#sheetOverlay');
  const sheet   = $(`#${sheetId}`);
  if (!sheet) return;
  sheet.classList.remove('open');
  clearSheetDrag(sheet);
  if (!$$('.bottom-sheet.open').length) overlay?.classList.remove('visible');
}

function closeAllSheets() {
  $$('.bottom-sheet').forEach(s => { s.classList.remove('open'); clearSheetDrag(s); });
  $('#sheetOverlay')?.classList.remove('visible');
}

/* ─── Wire up settings rows that open sheets ─── */
$('#themeSettingRow')?.addEventListener('click', () => openSheet('themeSheet'));
$('#langSettingRow')?.addEventListener('click',  () => openSheet('langSheet'));
$('#styleSettingRow')?.addEventListener('click', () => openSheet('styleSheet'));
$('#accentSettingRow')?.addEventListener('click', () => openSheet('accentSheet'));
$$('.sheet-option[data-accent-option]').forEach(opt => {
  opt.addEventListener('click', () => { applyAccent(opt.dataset.accentOption); applyTheme(State.theme); closeAllSheets(); });
});

/* ─── Sheet close buttons ─── */
$$('.sheet-header__close').forEach(btn => {
  btn.addEventListener('click', () => closeAllSheets());
});
$('#sheetOverlay')?.addEventListener('click', closeAllSheets);

/* ─── Theme sheet options ─── */
$$('.sheet-option[data-theme-option]').forEach(opt => {
  opt.addEventListener('click', () => { applyTheme(opt.dataset.themeOption); closeAllSheets(); });
});

/* ─── Style sheet options ─── */
$$('.sheet-option[data-style-option]').forEach(opt => {
  opt.addEventListener('click', () => {
    applyStyle(opt.dataset.styleOption);
    applyTheme(State.theme);            // re-sync theme-color meta to the new --bg-base
    closeAllSheets();
  });
});

/* ─── Auto system theme listener ─── */
window.matchMedia('(prefers-color-scheme:dark)').addEventListener('change', () => {
  if (State.theme === 'auto') applyTheme('auto');
});

/* ─── Init from saved prefs ─── */
const _savedTheme = (() => { try { return localStorage.getItem('copg-theme') || 'light'; } catch(_){ return 'light'; }})();   // default: light
// 'clean' = the pre-rename value of 'paper' (dev builds only)
const _savedStyle = (() => { try { const v = localStorage.getItem('copg-style'); return v === 'clean' ? 'paper' : (v || 'paper'); } catch(_){ return 'paper'; }})();   // default: Paper
const _savedLang  = (() => { try { return localStorage.getItem('copg-lang')  || 'en';   } catch(_){ return 'en';   }})();
buildLangSheet();
applyStyle(_savedStyle);
applyTheme(_savedTheme);
applyLanguage(I18N.has(_savedLang) ? _savedLang : 'en');
