# Force real /proc/cpuinfo: drop any leaked companion/controller bind before the module goes, so
# cpuinfo is real even without the post-uninstall reboot. NoMount redirects are per-process and
# clear on reboot; this handles the legacy global bind. Lazy-detach stacked binds (capped).
i=0; while [ $i -lt 8 ]; do umount -l /proc/cpuinfo 2>/dev/null || break; i=$((i+1)); done

rm -rf /data/adb/modules/COPG
rm -rf /data/adb/.config/COPG                              # COPG state: license backup, served.jsonl, .rand, proxy/, .copgts, bootid
rm -rf /data/adb/COPG /data/adb/copg                       # legacy pre-migration state dirs
rm -f  /data/adb/.copgts                                   # legacy license time-floor (now inside .config/COPG)
rm -rf /data/adb/copg_state                                # legacy global controller state
rm -f  /data/adb/copg_defaults /data/adb/copg_defaults.*   # controller tweak backups (.brightness/.dnd/.timeout/.nolog)
rm -f  /data/system/copg_*                                 # sysserver-hook state: *_bootguard counters, *.txt snapshots, copg_hb/copg_ss_hb, copg_micshare (NOT packages.list)
# Don't modify anything after this
if [ -f $INFO ]; then
  while read LINE; do
    if [ "$(echo -n $LINE | tail -c 1)" == "~" ]; then
      continue
    elif [ -f "$LINE~" ]; then
      mv -f $LINE~ $LINE
    else
      rm -f $LINE
      while true; do
        LINE=$(dirname $LINE)
        [ "$(ls -A $LINE 2>/dev/null)" ] && break 1 || rm -rf $LINE
      done
    fi
  done < $INFO
  rm -f $INFO
fi
