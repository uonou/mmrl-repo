#!/system/bin/sh
# Share a file to the Android share sheet via MediaStore. The file lives in /sdcard/Download (our own
# path, MediaStore-indexed) — scan it, look up its content://media uri, and SEND that. Telegram/Gmail
# read a content://media uri via their OWN storage permission (no grant, no copy, no app FileProvider
# needed). A file:// SEND is rejected ("unsupported attachment"), and a WebUI has no provider of its own.
# NEW_TASK|MULTIPLE_TASK (0x18000000) forces a FRESH share sheet — with NEW_TASK alone WebUI-X's
# am start got "delivered to the currently running top-most instance" (app already open) → mishandled
# → "unsupported attachment". MIME must be */* — a specific archive MIME is also rejected.
#   usage: sh share.sh <abs-file-path> [mime]
P="$1"; MIME="${2:-*/*}"
[ -f "$P" ] || { echo "no file: $P" >&2; exit 1; }
N="$(basename "$P")"
content call --uri content://media/external --method scan_file --arg "$P" >/dev/null 2>&1
ID=$(content query --uri content://media/external/file --projection _id --where "_display_name='$N'" 2>/dev/null | grep -o '_id=[0-9]*' | head -1 | cut -d= -f2)
[ -n "$ID" ] || { echo "not in MediaStore: $N" >&2; exit 1; }
exec su 2000 -c "am start -a android.intent.action.SEND -f 0x18000000 --eu android.intent.extra.STREAM content://media/external/file/$ID -t '$MIME' --grant-read-uri-permission"
